#include <algorithm>
#include <iostream>
#include <time.h>
#include <fstream>
#include <string>

using namespace std;

int main()

{
    int choice;
    string mystring;
    cout << "Welcome to the course planner." << endl;
    cout << " " << endl;
    cout << "  1. Load Data Structure" << endl;
    cout << "  2. Print Course List." << endl;
    cout << "  3. Print Course" << endl;
    cout << "  9. Exit" << endl;
    cout << " " << endl;
    cout << "What would you like to do?" << endl;

    cin >> choice;

    switch (choice) {

    case 1:
        std::ifstream myfile;
        myfile.open("CourseInformation.txt");
        if (myfile.is_open()) {
            while (!myfile.eof())
            {
                myfile >> mystring;
                std::cout << mystring << endl;
            }
            break;
        }

    }

}
   


